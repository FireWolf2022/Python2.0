filas = 3
columnas = 4
matriz = [[0] * columnas for _ in range(filas)]
print(matriz)

lista = [["oooo"] * 3 for _ in range(2)]
print(lista)